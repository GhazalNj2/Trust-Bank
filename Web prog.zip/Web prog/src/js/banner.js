// banner.js
document.addEventListener('DOMContentLoaded', function() {
  const closeButton = document.querySelector('.close-banner');
  const banner = document.querySelector('.banner');

  if (closeButton && banner) {
      closeButton.addEventListener('click', function() {
          banner.style.display = 'none';
      });
  }
});