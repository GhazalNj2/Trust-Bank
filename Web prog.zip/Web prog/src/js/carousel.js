document.addEventListener('DOMContentLoaded', function() {
// to ensure the script runs only when html has loaded.
//DOMContentLoaded is an event that fires when the document structure is ready.
// Sandwich and bread example

  const carousel = document.querySelector('.hero-carousel');
//selects the main carousel container from the HTML(class .hero-carousel)

  const slides = carousel.querySelectorAll('.carousel-slide');
//Finds elements inside .hero-carousel, have the class .carousel-slide(each slide in the carousel)

  const indicatorsContainer = carousel.querySelector('.carousel-indicators');
//Find the container to where dots (navigation) go?

  let currentSlide = 0;
//Start from first slide

  let intervalId;
//intervalId;  Will later store the ID of the setInterval function to auto-rotates the slides.




  // Create indicators
  slides.forEach((_, index) => {
// make loops for all slides and make dot for each.

      const indicator = document.createElement('div');
      indicator.classList.add('indicator');
// create new element <div> and asign it the class .indicator
// to switch the diffrenet slides(match them)

      if (index === 0) indicator.classList.add('active');
// marking the first slide as start point

      indicator.addEventListener('click', () => goToSlide(index));
// add a dot to click, when click show the coresponding slide.

      indicatorsContainer.appendChild(indicator);
  });
// add the dots to the container.

  const indicators = indicatorsContainer.querySelectorAll('.indicator');
//select all dots



//func that changes the visible slide:
  function goToSlide(index) {
      // Remove active class from current slide and indicator
      slides[currentSlide].classList.remove('active');
      indicators[currentSlide].classList.remove('active');
      
      // Update current slide
      currentSlide = index;
      
      // Add active class to new slide and indicator
      slides[currentSlide].classList.add('active');
      indicators[currentSlide].classList.add('active');
  }


//func to move to next slide:
// there is a loop
  function nextSlide() {
      let nextIndex = currentSlide + 1;
      if (nextIndex >= slides.length) {
          nextIndex = 0;
      }
      goToSlide(nextIndex);
      //call gotoslide func to switch the next slide.
  }


  // Start automatic rotation
  // change clide every 3 sec
  function startCarousel() {
      intervalId = setInterval(nextSlide, 3000);
  }

  // Pause on hover(when mouse is over carousel)
  carousel.addEventListener('mouseenter', () => {
      clearInterval(intervalId);
  });
//Resume carousel when the mouse leaves
  carousel.addEventListener('mouseleave', startCarousel);

  // Start the carousel when page load
  startCarousel();
});   