function updateClock() {
    // find the html elem with id='clock'.(where the time display)
    let clockElement = document.querySelector('#clock');
    // find the html elem with id='date'
    let dateElement = document.querySelector('#date');
    // create new date->for current date and time
    let now = new Date();
    
    // Format time
    let hours = now.getHours().toString().padStart(2, '0'); // get the current hours(0-23)
    let minutes = now.getMinutes().toString().padStart(2, '0'); // current mins(0-59)
    let seconds = now.getSeconds().toString().padStart(2, '0'); // curr secs (0-59)
    //(tostring-> convert num to sting)
    // Update the clock element with the current time
    // (2, '0')-> add zero behind num (01),...(09)
    // 9:5:3 -> 09:05:03

    // Display the clock
    clockElement.innerText = `${hours}:${minutes}:${seconds}`;
    //updating #clock in html with formated time.

    // Format and update date
    //options (object)-> Formating rules
    const options = { 
        weekday: 'long', // Displays full weekday name 
        year: 'numeric', // full year
        month: 'long', // full month name
        day: 'numeric' // day of month 
    };
    dateElement.innerText = now.toLocaleDateString('en-US', options);
    //tolocaldatestring()->display the current date in a readable format.
    //'en_US' language: english united states (fa-IR: farsi, Iran)

    //options->structure the data
    //example: tuesday, Jannuary 6, 2025
}
 
// Update the clock every second
setInterval(updateClock, 1000);
//Calls updateClock() every 1000ms (1 second) to update the time continuously.

// Run the clock function once when the page loads
updateClock(); // Run the func when page loads (immediately)