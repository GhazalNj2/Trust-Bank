// Get references to banner elements
const fakeBanner = document.querySelector('.fake-bank-banner');
const warningText = document.querySelector('.fake-banner-content');
const emojiContainer = document.querySelector('.animate-bounce');

// Array of fun emoji combinations to cycle through
const emojiSets = [
    '💸 🏦 💸',
    '🦄 💰 🌈',
    '💰 💵 💳',
    '🎰 💎 🎲',
    '🤑 💵 🤑',
    '🚔 💰 🦹‍♂️',
    '🚔 🚨 👮‍♂️',
    '💎 💰 🛍️'
];



// Function to cycle through emoji sets
let currentEmojiIndex = 0;
function cycleEmojis() {
    if (emojiContainer) {
        emojiContainer.style.opacity = '0';
        setTimeout(() => {
            currentEmojiIndex = (currentEmojiIndex + 1) % emojiSets.length;
            emojiContainer.textContent = emojiSets[currentEmojiIndex];
            emojiContainer.style.opacity = '1';
        }, 500);
    }
}

// Start emoji cycling every 3 seconds
setInterval(cycleEmojis, 1000);

// Fun hover effect for the banner
if (fakeBanner) {
    fakeBanner.addEventListener('mouseover', () => {
        const colors = [
            'from-pink-500 via-purple-500 to-blue-500',
            'from-green-500 via-yellow-500 to-red-500',
            'from-blue-500 via-teal-500 to-green-500'
        ];
        
        const randomColor = colors[Math.floor(Math.random() * colors.length)];
        fakeBanner.style.background = `linear-gradient(45deg, ${getRandomColor()}, ${getRandomColor()})`;
    });
}

// Function to generate random colors
function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}



// close: 


const closeButton = document.createElement('button');
closeButton.className = 'close-banner';
closeButton.innerHTML = '<i class="fas fa-times"></i>';
if (warningText) {
    warningText.appendChild(closeButton);
}

closeButton.addEventListener('click', (e) => {
    e.stopPropagation(); // Prevent triggering the banner click event
    if (fakeBanner) {
        fakeBanner.style.display = 'none';
    }
});