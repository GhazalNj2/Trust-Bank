<?php
function sanitize($data) {
    global $conn; // Use the database connection
    return mysqli_real_escape_string($conn, htmlspecialchars($data, ENT_QUOTES, 'UTF-8'));
}
