<?php
// Remove any whitespace or HTML before this line
session_start();
require('DBconnection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize($_POST['email']);
    $password = sanitize($_POST['password']);

    // Admin login check
    $admin_query = "SELECT * FROM admin WHERE email = ?";
    $admin_stmt = $conn->prepare($admin_query);
    
    if ($admin_stmt) {
        $admin_stmt->bind_param("s", $email);
        $admin_stmt->execute();
        $admin_result = $admin_stmt->get_result();
        
        if ($admin_result->num_rows > 0) {
            $admin_row = $admin_result->fetch_assoc();
            if (password_verify($password, $admin_row['password'])) {
                $_SESSION['admin_id'] = $admin_row['id'];
                $_SESSION['username'] = $admin_row['firstname'] . ' ' . $admin_row['lastname'];
                $_SESSION['email'] = $admin_row['email'];
                header("Location: admin_dashboard.php");
                exit();
            } else {
                echo "<script>alert('Incorrect admin password.');</script>";
            }
        } else {
            // User login check
            $user_query = "SELECT * FROM users WHERE email = ?";
            $user_stmt = $conn->prepare($user_query);
            
            if ($user_stmt) {
                $user_stmt->bind_param("s", $email);
                $user_stmt->execute();
                $user_result = $user_stmt->get_result();
                
                if ($user_result->num_rows > 0) {
                    $user_row = $user_result->fetch_assoc();
                    if (password_verify($password, $user_row['password'])) {
                        $_SESSION['user_id'] = $user_row['id'];
                        $_SESSION['username'] = $user_row['firstname'] . ' ' . $user_row['lastname'];
                        $_SESSION['email'] = $user_row['email'];
                        header("Location: profile.php");
                        exit();
                    } else {
                        echo "<script>alert('Incorrect user password.');</script>";
                    }
                } else {
                    echo "<script>alert('User not found.');</script>";
                }
                $user_stmt->close();
            } else {
                error_log("Error preparing user statement: " . $conn->error);
            }
        }
        $admin_stmt->close();
    } else {
        error_log("Error preparing admin statement: " . $conn->error);
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - TRUST</title>
    <link rel="stylesheet" href="/css/login.css">
    
    <!-- Add FontAwesome for the banner close icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <!-- Header Section -->
    <header class="header fixed-top">
        <div class="header-background"></div>
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <!-- Logo -->
                <a href="../index.html#home" class="logo">
                    <img src="../images/bank-logo.png" alt="TRUST Bank Logo" class="logo-img">
                    <span>TRUST Bank </span>
                </a>

                <!-- Navigation -->
                <nav class="nav">
                    <a href="../index.html#home">Home Page</a>
                    <a href="../index.html#about">About Us</a>
                    <a href="../services-page.html">Services</a>
                    <a href="../membership-plans.html">Members Club</a>
                    <a href="register.php">Not a member yet?</a>
                </nav>

                <a href="appointment.php" class="link-btn">Schedule an Appointment!</a>
                
                <!-- Clock Display -->
                <div class="clock-container">
                    <div id="clock" class="clock"></div>
                    <div id="date" class="date"></div>
                </div>
            </div>
        </div>
    </header>


    <!-- login section starts -->
    <section class="login" id="login">
        <h1 class="heading"> Sign In </h1>

        <div class="login-form">
            <form action="login.php" method="POST">
                <div class="form-parts">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-parts">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="btn">Sign In</button>

                <div class="form-parts">
                    <a href="register.php">Not a member yet?</a>

                </div>
            </form>
        </div>
    </section>
    <!-- login section ends -->

    <script src="../js/script.js"></script>
    <!-- Add clock script -->
    <script src="../js/clock.js"></script>
</body>
</html>