<?php
ob_start();
require_once('DBconnection.php');

// Initialize message variables
$success_message = "";
$error_message = "";

// Handle Add Booking
if (isset($_POST['add_booking'])) {
    $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8'); // Use htmlspecialchars for sanitization
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL); // Still valid for email
    $phone = htmlspecialchars($_POST['phone'], ENT_QUOTES, 'UTF-8');
    $reservation_date = htmlspecialchars($_POST['reservation_date'], ENT_QUOTES, 'UTF-8');
    $reservation_time = htmlspecialchars($_POST['reservation_time'], ENT_QUOTES, 'UTF-8');
    $message = htmlspecialchars($_POST['message'], ENT_QUOTES, 'UTF-8');

    $stmt = $conn->prepare("INSERT INTO reservations (name, email, phone, reservation_date, reservation_time, message) 
                            VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $email, $phone, $reservation_date, $reservation_time, $message);

    if ($stmt->execute()) {
        $success_message = "Booking successfully added!";
    } else {
        $error_message = "Error adding booking. Please try again.";
    }
}

// Fetch all bookings for the provided email (if submitted)
$user_bookings = [];
if (isset($_POST['view_email'])) {
    $email = filter_var($_POST['view_email'], FILTER_SANITIZE_EMAIL);
    $stmt = $conn->prepare("SELECT * FROM reservations WHERE email = ? ORDER BY reservation_date DESC");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user_bookings = $result->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments</title>
    <link rel="stylesheet" href="/css/appointment.css">
</head>
<body>
    <header>
        <h1>Appointments</h1>
        <nav>
            <a href="profile.php">Back To HomePage</a>
        </nav>
    </header>

    <?php if (!empty($success_message)): ?>
        <div class="alert success"><?php echo htmlspecialchars($success_message); ?></div>
    <?php endif; ?>

    <?php if (!empty($error_message)): ?>
        <div class="alert error"><?php echo htmlspecialchars($error_message); ?></div>
    <?php endif; ?>

    <!-- Booking Form -->
    <section>
        <h2>Reserve an Appointment</h2>
        <form action="" method="POST">
            <input type="hidden" name="add_booking" value="1">

            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="tel" id="phone" name="phone" required>
            </div>

            <div class="form-group">
                <label for="reservation_date">Reservation Date:</label>
                <input type="date" id="reservation_date" name="reservation_date" min="<?php echo date('Y-m-d'); ?>" required>
            </div>

            <div class="form-group">
                <label for="reservation_time">Reservation Time:</label>
                <input type="time" id="reservation_time" name="reservation_time" required>
            </div>

            <div class="form-group">
                <label for="message">Message:</label>
                <textarea id="message" name="message"></textarea>
            </div>

            <button type="submit" class="btn">Book Appointment</button>
        </form>
    </section>

    <!-- View Bookings -->
    <section>
        <h2>View Your Bookings</h2>
        <form action="" method="POST">
            <div class="form-group">
                <label for="view_email">Enter Your Email:</label>
                <input type="email" id="view_email" name="view_email" required>
            </div>
            <button type="submit" class="btn">View Appointments</button>
        </form>

        <?php if (!empty($user_bookings)): ?>
            <h3>Your Bookings</h3>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Reservation Date</th>
                        <th>Reservation Time</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($user_bookings as $booking): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($booking['name']); ?></td>
                            <td><?php echo htmlspecialchars($booking['email']); ?></td>
                            <td><?php echo htmlspecialchars($booking['phone']); ?></td>
                            <td><?php echo htmlspecialchars($booking['reservation_date']); ?></td>
                            <td><?php echo htmlspecialchars($booking['reservation_time']); ?></td>
                            <td><?php echo htmlspecialchars($booking['message']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>

    <script>
        // Validate future dates only
        document.addEventListener('DOMContentLoaded', function() {
            const dateInput = document.getElementById('reservation_date');
            if (dateInput) {
                dateInput.addEventListener('change', function() {
                    const selectedDate = new Date(this.value);
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);

                    if (selectedDate < today) {
                        alert('Please select a future date');
                        this.value = '';
                    }
                });
            }
        });
    </script>
</body>
</html>
<?php
ob_end_flush();
?>
