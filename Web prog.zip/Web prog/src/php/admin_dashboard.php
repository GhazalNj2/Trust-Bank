<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
session_start();
require('DBconnection.php');

// Validate admin session
if (!isset($_SESSION['admin_id'])) {
    error_log("Unauthorized access attempt to admin dashboard");
    header('Location: index.html');
    ob_end_clean();
    exit();
}

// Secure query function to prevent SQL injection
function safeQuery($conn, $query, $params = null) {
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        error_log("Prepare failed: " . mysqli_error($conn));
        return false;
    }
    
    if ($params) {
        $types = str_repeat('s', count($params));
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }
    
    if (!mysqli_stmt_execute($stmt)) {
        error_log("Query execution failed: " . mysqli_stmt_error($stmt));
        return false;
    }
    
    return $stmt;
}

// Validate and sanitize input
function sanitizeInput($input) {
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input);
    return $input;
}

// Handle user deletion
if (isset($_GET['delete_user_id'])) {
    $user_id = filter_input(INPUT_GET, 'delete_user_id', FILTER_VALIDATE_INT);
    
    if ($user_id) {
        mysqli_begin_transaction($conn);
        try {
            $delete_reservation_query = "DELETE FROM reservations WHERE email = (SELECT email FROM users WHERE id = ?)";
            safeQuery($conn, $delete_reservation_query, [$user_id]);
            
            $delete_user_query = "DELETE FROM users WHERE id = ?";
            safeQuery($conn, $delete_user_query, [$user_id]);
            
            mysqli_commit($conn);
            header('Location: admin_dashboard.php#users');
            ob_end_clean();
            exit();
        } catch (Exception $e) {
            mysqli_rollback($conn);
            error_log("Deletion error: " . $e->getMessage());
        }
    }
}

// Handle reservation deletion
if (isset($_GET['delete_reservation_id'])) {
    $reservation_id = filter_input(INPUT_GET, 'delete_reservation_id', FILTER_VALIDATE_INT);
    
    if ($reservation_id) {
        $query = "DELETE FROM reservations WHERE id = ?";
        safeQuery($conn, $query, [$reservation_id]);
        header('Location: admin_dashboard.php#reservations');
        ob_end_clean();
        exit();
    }
}

// Handle user edit
if (isset($_GET['edit_user_id'])) {
    $user_id = filter_input(INPUT_GET, 'edit_user_id', FILTER_VALIDATE_INT);
    
    if ($user_id) {
        $query = "SELECT * FROM users WHERE id = ?";
        $stmt = safeQuery($conn, $query, [$user_id]);
        $result = mysqli_stmt_get_result($stmt);
        $user = mysqli_fetch_assoc($result);

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $firstname = sanitizeInput($_POST['firstname']);
            $middlename = sanitizeInput($_POST['middlename']);
            $lastname = sanitizeInput($_POST['lastname']);
            $phone = sanitizeInput($_POST['phone']);
            $address = sanitizeInput($_POST['address']);

            $update_query = "UPDATE users SET firstname=?, middlename=?, lastname=?, phone=?, address=? WHERE id = ?";
            $update_stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($update_stmt, 'sssssi', $firstname, $middlename, $lastname, $phone, $address, $user_id);
            
            if (mysqli_stmt_execute($update_stmt)) {
                header('Location: admin_dashboard.php#users');
                ob_end_clean();
                exit();
            } else {
                error_log("Error updating user: " . mysqli_error($conn));
            }
        }
    }
}

// Handle reservation edit
if (isset($_GET['edit_reservation_id'])) {
    $reservation_id = filter_input(INPUT_GET, 'edit_reservation_id', FILTER_VALIDATE_INT);
    
    if ($reservation_id) {
        $query = "SELECT * FROM reservations WHERE id = ?";
        $stmt = safeQuery($conn, $query, [$reservation_id]);
        $result = mysqli_stmt_get_result($stmt);
        $reservation = mysqli_fetch_assoc($result);

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $name = sanitizeInput($_POST['name']);
            $phone = sanitizeInput($_POST['phone']);
            $reservation_date = sanitizeInput($_POST['reservation_date']);
            $reservation_time = sanitizeInput($_POST['reservation_time']);

            $update_query = "UPDATE reservations SET name=?, phone=?, reservation_date=?, reservation_time=? WHERE id = ?";
            $update_stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($update_stmt, 'ssssi', $name, $phone, $reservation_date, $reservation_time, $reservation_id);
            
            if (mysqli_stmt_execute($update_stmt)) {
                header('Location: admin_dashboard.php#reservations');
                ob_end_clean();
                exit();
            } else {
                error_log("Error updating reservation: " . mysqli_error($conn));
            }
        }
    }
}

// Fetch users
$user_query = "SELECT * FROM users";
$user_result = mysqli_query($conn, $user_query);

// Fetch reservations with user names
$reservation_query = "
    SELECT reservations.*, 
    CONCAT(users.firstname, ' ', COALESCE(users.middlename, ''), ' ', users.lastname) AS user_name
    FROM reservations
    LEFT JOIN users ON reservations.email = users.email";
$reservation_result = mysqli_query($conn, $reservation_query);

ob_end_flush(); // Send output buffer
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: hsl(233deg 36% 38%);
            --secondary-color: #00bcd4;
            --accent-color: #e74c3c;
            --background-color: hsl(218deg 50% 91%);
            --white: #ffffff;
            --text-color: #2c3e50;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: var(--background-color);
            color: var(--text-color);
            line-height: 1.6;
            padding-top: 100px;
        }

        header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: var(--white);
            box-shadow: 0 0 2em hsl(231deg 62% 94%);
            z-index: 1000;
            padding: 1rem 0;
        }

        header h1 {
            color: var(--primary-color);
            text-align: center;
            font-size: 1.5rem;
        }

        .navbar {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-top: 0.5rem;
        }

        .navbar a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .navbar a:hover {
            color: var(--secondary-color);
        }

        .admin-dashboard {
            width: 90%;
            max-width: 1200px;
            margin: 2rem auto;
            background: var(--white);
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 20px rgba(0,0,0,0.05);
        }

        .admin-dashboard h2 {
            color: var(--primary-color);
            margin-bottom: 1.5rem;
            text-align: center;
            position: relative;
            padding-bottom: 1rem;
        }

        .admin-dashboard h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: var(--secondary-color);
        }

        .box-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
        }

        .box {
            background: var(--background-color);
            padding: 1.5rem;
            border-radius: 15px;
            transition: transform 0.3s ease;
        }

        .box:hover {
            transform: translateY(-5px);
        }

        .btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            background: var(--primary-color);
            color: var(--white);
            text-decoration: none;
            border-radius: 30px;
            margin-top: 1rem;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background: var(--secondary-color);
        }

        .delete-btn {
            background: var(--accent-color);
        }

        .delete-btn:hover {
            background: #c0392b;
        }

        #edit-section form {
            display: grid;
            gap: 1rem;
            max-width: 500px;
            margin: 0 auto;
        }

        #edit-section label {
            color: var(--primary-color);
            font-weight: 500;
        }

        #edit-section input {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid var(--secondary-color);
            border-radius: 5px;
        }

        @media (max-width: 768px) {
            .box-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
<header>
    <h1>Management Section</h1>
    <nav class="navbar">
        <a href="#users">Users</a>
        <a href="#reservations">Reservations</a>
        
    </nav>
</header>

<!-- Users Section -->
<section class="admin-dashboard" id="users">
    <h2>Users Data</h2>
    <div class="box-container">
        <?php while ($row = mysqli_fetch_assoc($user_result)): ?>
        <div class="box user-box">
            <h3><?php echo htmlspecialchars($row['firstname'] . ' ' . $row['middlename'] . ' ' . $row['lastname']); ?></h3>
            <p>Email: <?php echo htmlspecialchars($row['email']); ?></p>
            <p>Phone: <?php echo htmlspecialchars($row['phone']); ?></p>
            <p>Address: <?php echo htmlspecialchars($row['address']); ?></p>
            <a href="admin_dashboard.php?edit_user_id=<?php echo $row['id']; ?>#edit-section" class="btn">Edit</a>
            <a href="admin_dashboard.php?delete_user_id=<?php echo $row['id']; ?>" class="btn delete-btn">Delete</a>
        </div>
        <?php endwhile; ?>
    </div>
</section>

<!-- Reservations Section -->
<section class="admin-dashboard" id="reservations">
    <h2>Reservations</h2>
    <div class="box-container">
        <?php while ($row = mysqli_fetch_assoc($reservation_result)): ?>
        <div class="box reservation-box">
            <h3>Reservation NO: <?php echo htmlspecialchars($row['id']); ?></h3>
            <p>Name: <?php echo htmlspecialchars($row['name']); ?></p>
            <p>Email: <?php echo htmlspecialchars($row['email']); ?></p>
            <p>Phone: <?php echo htmlspecialchars($row['phone']); ?></p>
            <p>Reservation Date: <?php echo htmlspecialchars($row['reservation_date']); ?></p>
            <p>Reservation Time: <?php echo htmlspecialchars($row['reservation_time']); ?></p>
            <p>User: <?php echo isset($row['user_name']) ? htmlspecialchars($row['user_name']) : 'Unknown'; ?></p>
            <a href="admin_dashboard.php?edit_reservation_id=<?php echo $row['id']; ?>#edit-section" class="btn">Edit</a>
            <a href="admin_dashboard.php?delete_reservation_id=<?php echo $row['id']; ?>" class="btn delete-btn">Cancel</a>
        </div>
        <?php endwhile; ?>
    </div>
</section>

<!-- Edit User or Reservation Form -->
<section class="admin-dashboard" id="edit-section">
    <?php if (isset($_GET['edit_user_id'])): ?>
    <h2>Edit User</h2>
    <form action="" method="POST">
        <label for="firstname">First Name:</label>
        <input type="text" name="firstname" value="<?php echo htmlspecialchars($user['firstname']); ?>" required>
        <label for="middlename">Middle Name:</label>
        <input type="text" name="middlename" value="<?php echo htmlspecialchars($user['middlename']); ?>">
        <label for="lastname">Last Name:</label>
        <input type="text" name="lastname" value="<?php echo htmlspecialchars($user['lastname']); ?>" required>
        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" readonly>
        <label for="phone">Phone:</label>
        <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
        <label for="address">Address:</label>
        <input type="text" name="address" value="<?php echo htmlspecialchars($user['address']); ?>" required>
        <button type="submit" class="btn">Update</button>
    </form>
    <?php endif; ?>

    <?php if (isset($_GET['edit_reservation_id'])): ?>
    <h2>Edit Reservation</h2>
    <form action="" method="POST">
        <label for="name">Name:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($reservation['name']); ?>" required>
        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($reservation['email']); ?>" readonly>
        <label for="phone">Phone:</label>
        <input type="text" name="phone" value="<?php echo htmlspecialchars($reservation['phone']); ?>" required>
        <label for="reservation_date">Reservation Date:</label>
        <input type="date" name="reservation_date" value="<?php echo htmlspecialchars($reservation['reservation_date']); ?>" required>
        <label for="reservation_time">Reservation Time:</label>
        <input type="time" name="reservation_time" value="<?php echo htmlspecialchars($reservation['reservation_time']); ?>">
        <button type="submit" class="btn">Update</button>
    </form>
    <?php endif; ?>
</section>

<script src="js/script.js"></script>
</body>
</html>