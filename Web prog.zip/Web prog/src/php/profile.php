<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TRUST Bank - Your Trusted Financial Partner</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.1/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/css/profile.css">
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <!-- Header Section -->
    <header class="header fixed-top">
        <div class="header-background"></div>
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <!-- Logo -->
                <a href="#home" class="logo">
                    <img src="../images/bank-logo.png" alt="TRUST Bank Logo" class="logo-img">
                    <span>TRUST Bank </span>
                </a>
                <!-- Navigation -->
                <nav class="nav">
                    <a href="#home">Home Page</a>
                    <a href="#about">About Us</a>
                    <a href="../services-page-cus.html">Services</a>
                    <a href="../membership-plans-cus.html">Members Club</a>
                    <a href="user_dashboard.php">Personal info</a>
                    <a href="signout.php">Sign Out </a>
                </nav>
                <a href="appointment-cus.php" class="link-btn">Schedule an Appointment</a>
                <!-- Clock Display -->
                <div class="clock-container">
                    <div id="clock" class="clock"></div>
                    <div id="date" class="date"></div>
                </div>
            </div>
        </div>
    </header>
    <section class="user-welcome">
    <div class="container">
        <div class="welcome-content">
            <h2>Customer's Area</h2>
            <p>Do you want to review your personal information?</p>
            <a href="user_dashboard.php"> click here </a>
        </div>
    </div>
</section>
    <section class="hero" id="home">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1>Welcome to TRUST Bank</h1>
                    <p>Your trusted partner in financial growth and security.</p>
                    <div class="hero-buttons">
                        <a href="../services-page.html" class="btn btn-primary">Our Services</a>
                        <a href="../membership-plans.html" class="btn btn-outline-light">Learn More</a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="hero-carousel">
                        <div class="carousel-container">
                            <img src="/images/bank1.jpg" alt="Banking Services" class="carousel-slide active">
                            <img src="/images/bank2.jpg" alt="Customer Service" class="carousel-slide">
                            <img src="/images/bank3.jpg" alt="Mobile Banking" class="carousel-slide">
                            <img src="/images/bank4.jpg" alt="Investment Services" class="carousel-slide">
                            <img src="/images/bank5.jpg" alt="Investment Services" class="carousel-slide">
                            <img src="/images/bank6.jpg" alt="Investment Services" class="carousel-slide">
                        </div>
                        <div class="carousel-indicators">
                            <!-- Indicators will be added by JavaScript -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
            <!-- Market Updates Section -->
            <div class="row mb-5">
                <div class="col-12">
                    <div class="market-updates">
                        <h3 class="section-title">Today's Market Updates</h3>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="market-card">
                                    <h4>USD/EUR</h4>
                                    <p class="rate">1.1234 <span class="trend-up"><i class="fas fa-arrow-up"></i> 0.05%</span></p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="market-card">
                                    <h4>Gold</h4>
                                    <p class="rate">$1,892.30 <span class="trend-down"><i class="fas fa-arrow-down"></i> 0.12%</span></p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="market-card">
                                    <h4>S&P 500</h4>
                                    <p class="rate">4,185.25 <span class="trend-up"><i class="fas fa-arrow-up"></i> 0.28%</span></p>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="market-card">
                                    <h4>Bitcoin</h4>
                                    <p class="rate">$42,850 <span class="trend-up"><i class="fas fa-arrow-up"></i> 1.45%</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
            <!-- Financial Tips Section -->
            <div class="row mb-5">
                <div class="col-12">
                    <div class="tips-section">
                        <h3 class="section-title">Financial Tips & Insights</h3>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="tip-card">
                                    <h4><i class="fas fa-lightbulb"></i> Smart Saving Tip of the Day</h4>
                                    <p>Use the 50/30/20 rule: Spend 50% on needs, 30% on wants, and save 20% of your income.</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="tip-card">
                                    <h4><i class="fas fa-chart-line"></i> Investment Insight</h4>
                                    <p>Diversifying your portfolio can help minimize risk and maximize potential returns.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    
            <!-- Quick Actions Section -->
            <div class="row">
                <div class="col-12">
                    <div class="quick-actions">
                        <h3 class="section-title">Quick Actions</h3>
                        <div class="action-buttons">
                            <a href="../oops.html" class="action-btn"><i class="fas fa-exchange-alt"></i> Transfer Money</a>
                            <a href="../oops.html" class="action-btn"><i class="fas fa-file-invoice-dollar"></i> Pay Bills</a>
                            <a href="../oops.html" class="action-btn"><i class="fas fa-mobile-alt"></i> Mobile Deposit</a>
                            <a href="../oops.html" class="action-btn"><i class="fas fa-history"></i> Transaction History</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <footer class="footer" id="about">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h4>Contact Us</h4>
                    <p><i class="fas fa-phone"></i> 1-800-TRUST-BANK</p>
                    <p><i class="fas fa-envelope"></i> info@trustbank.com</p>
                    <p><i class="fas fa-map-marker-alt"></i> 123 Banking Street, Finance City</p>
                </div>
                <div class="col-md-4">
                    <h4>Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="#about">About Us</a></li>
                        <li><a href="../services-page.html">Services</a></li>
                        <li><a href="../membership-plans.html">Members Club</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h4>Follow Us</h4>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="/js/script.js"></script>
    <script src="/js/clock.js"></script>
    <script src="/js/banner.js"></script>
    <script src="/js/carousel.js"></script>
</body>
</html>





<?php
// Start the session
session_start();

// Check if the user is logged in, otherwise redirect to login page
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get the user's information from session variables (assuming user info is stored in session)
$firstname = isset($_SESSION['firstname']) ? $_SESSION['firstname'] : 'Unknown';
$lastname = isset($_SESSION['lastname']) ? $_SESSION['lastname'] : 'User';

// Alternatively, you can fetch this data from the database if needed
// require('DBconnection.php'); 
// $user_id = $_SESSION['user_id'];
// $sql = "SELECT firstname, lastname FROM users WHERE id = ?";
// $stmt = $conn->prepare($sql);
// $stmt->bind_param('i', $user_id);
// $stmt->execute();
// $result = $stmt->get_result();
// $user = $result->fetch_assoc();
// $firstname = $user['firstname'];
// $lastname = $user['lastname'];
?>
