<?php
ob_start();  // Start output buffering
session_start(); 

require('DBconnection.php');


require_once 'utilities.php';
// Use sanitize()


function emailExists($email) {
    global $conn;
    $email = sanitize($email);
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);
    return $result->num_rows > 0;
}

function validatePassword($password) {
    return true; 
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = sanitize($_POST['email']);
    $password = sanitize($_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    if (emailExists($email)) {
        echo "Error: Email already exists. Please choose a different email.";
        exit();  // Terminate the script after error output
    }

    if (!validatePassword($password)) {
        echo "Error: Password does not meet requirements.";
        exit();  // Terminate the script after error output
    }

    $firstname = sanitize($_POST['firstname']);
    $middlename = sanitize($_POST['middlename']);
    $lastname = sanitize($_POST['lastname']);
    $gender = sanitize($_POST['gender']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);

    $sql = "INSERT INTO users (firstname, middlename, lastname, gender, phone, address, email, password)
            VALUES ('$firstname', '$middlename', '$lastname', '$gender', '$phone', '$address', '$email', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        $_SESSION['email'] = $email; 
        
        // Redirect to the login page after successful registration
        header("Location: login.php");
        exit();  // Always exit after a header redirect
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
ob_end_flush();  // End output buffering and send output
?>
