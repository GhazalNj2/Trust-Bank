<?php
require('DBconnection.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration</title>
    <link rel="stylesheet" href="/css/register.css">
<!-- connect the HTML document to an external CSS file named register.css-->
</head>
<body>
    <!-- Header Section -->
    <header class="header fixed-top">
        <div class="header-background"></div>
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <!-- Logo -->
                <a href="../index.html#home" class="logo">
                    <img src="../images/bank-logo.png" alt="TRUST Bank Logo" class="logo-img">
                    <span>TRUST Bank </span>
                </a>

                <!-- Navigation -->
                <nav class="nav">
                    <a href="../index.html#home">Home Page</a>
                    <a href="../index.html#about">About Us</a>
                    <a href="../services-page.html">Services</a>
                    <a href="../membership-plans.html">Members Club</a>
                    <a href="login.php">Sign In </a>
                </nav>

                <a href="appointment.php" class="link-btn">Schedule an Appointment!</a>
                
                <!-- Clock Display -->
                <div class="clock-container">
                    <div id="clock" class="clock"></div>
                    <div id="date" class="date"></div>
                </div>
            </div>
        </div>
    </header>

    
    <form action="proccess_register.php" method="post">
        <label>Firstname:</label>
        <input type="text" name="firstname" size="15" required/> <br> <br>
        
        <label>Middlename:</label>
        <input type="text" name="middlename" size="15"/> <br> <br>
        
        <label>Lastname:</label>
        <input type="text" name="lastname" size="15" required/> <br> <br>
        
        <label>Gender:</label> <br>
        <input type="radio" name="gender" value="male" id="male" required/>
        <label for="male">Male</label>
        <input type="radio" name="gender" value="female" id="female" required/>
        <label for="female">Female</label> <br> <br>
        
        <label>Phone:</label>
        <input type="text" name="phone" size="15" required/> <br> <br>
        
        <label>Address:</label> <br>
        <textarea name="address" cols="80" rows="5" required></textarea> <br> <br>
        
        <label>Email:</label>
        <input type="email" name="email" required/> <br> <br>
        
        <label>Password:</label>
        <input type="password" name="password" required> <br> <br>
        
        <label>Re-type password:</label>
        <input type="password" name="repassword" required> <br> <br>
        
        <div class="btn-container">
            <input type="submit" value="Register Now" class="btn"/>
        </div>
        <div class="form-parts">
                    <a href="login.php">Are you a member?</a>
                </div>
    </form>

    <script src="../js/script.js"></script>
    <script src="../js/clock.js"></script>

    </body>
</html>